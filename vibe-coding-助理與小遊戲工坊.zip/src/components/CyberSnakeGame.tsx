import React, { useEffect, useRef, useState, useCallback } from 'react';
import { soundManager } from '../utils/audio';
import confetti from 'canvas-confetti';
import { Play, RotateCcw, Trophy, ArrowUp, ArrowDown, ArrowLeft, ArrowRight, Sparkles } from 'lucide-react';
import type { GameSettings, GameStatus } from '../types';

type Point = { x: number; y: number };

interface CyberSnakeProps {
  settings: GameSettings;
}

const GRID_SIZE = 18;
const CELL_SIZE = 20;

export const CyberSnakeGame: React.FC<CyberSnakeProps> = ({ settings }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [status, setStatus] = useState<GameStatus>('idle');
  const [score, setScore] = useState(0);
  const [highScore, setHighScore] = useState(() => {
    return parseInt(localStorage.getItem('vibe_snake_highscore') || '0', 10);
  });

  const stateRef = useRef({
    status: 'idle' as GameStatus,
    snake: [
      { x: 9, y: 9 },
      { x: 8, y: 9 },
      { x: 7, y: 9 },
    ] as Point[],
    direction: { x: 1, y: 0 } as Point,
    nextDirection: { x: 1, y: 0 } as Point,
    food: { x: 14, y: 9 } as Point,
    score: 0,
    speed: 130, // ms per tick
  });

  const spawnFood = useCallback((currentSnake: Point[]) => {
    while (true) {
      const rx = Math.floor(Math.random() * GRID_SIZE);
      const ry = Math.floor(Math.random() * GRID_SIZE);
      const collision = currentSnake.some((segment) => segment.x === rx && segment.y === ry);
      if (!collision) {
        return { x: rx, y: ry };
      }
    }
  }, []);

  const startGame = () => {
    const s = stateRef.current;
    const initialSnake = [
      { x: 9, y: 9 },
      { x: 8, y: 9 },
      { x: 7, y: 9 },
    ];
    s.status = 'playing';
    s.snake = initialSnake;
    s.direction = { x: 1, y: 0 };
    s.nextDirection = { x: 1, y: 0 };
    s.food = spawnFood(initialSnake);
    s.score = 0;
    s.speed = 130;
    setScore(0);
    setStatus('playing');
    soundManager.playJump(settings.soundEnabled);
  };

  const changeDirection = useCallback((dx: number, dy: number) => {
    const s = stateRef.current;
    if (s.status !== 'playing') return;
    // Prevent 180-degree reversing
    if (s.direction.x + dx === 0 && s.direction.y + dy === 0) return;
    s.nextDirection = { x: dx, y: dy };
  }, []);

  // Main game tick interval
  useEffect(() => {
    if (status !== 'playing') return;

    const timer = setInterval(() => {
      const s = stateRef.current;
      if (s.status !== 'playing') return;

      s.direction = s.nextDirection;
      const head = s.snake[0];
      const newHead = {
        x: head.x + s.direction.x,
        y: head.y + s.direction.y,
      };

      // Wall collision check
      if (newHead.x < 0 || newHead.x >= GRID_SIZE || newHead.y < 0 || newHead.y >= GRID_SIZE) {
        s.status = 'gameover';
        setStatus('gameover');
        soundManager.playGameOver(settings.soundEnabled);
        if (s.score > highScore) {
          setHighScore(s.score);
          localStorage.setItem('vibe_snake_highscore', s.score.toString());
          confetti({ particleCount: 70, spread: 60, origin: { y: 0.6 } });
        }
        return;
      }

      // Self collision
      if (s.snake.some((seg) => seg.x === newHead.x && seg.y === newHead.y)) {
        s.status = 'gameover';
        setStatus('gameover');
        soundManager.playGameOver(settings.soundEnabled);
        return;
      }

      // Move snake forward
      s.snake.unshift(newHead);

      // Check food
      if (newHead.x === s.food.x && newHead.y === s.food.y) {
        s.score += 10;
        setScore(s.score);
        s.food = spawnFood(s.snake);
        s.speed = Math.max(70, 130 - Math.floor(s.score / 30) * 8);
        soundManager.playCollect(settings.soundEnabled);
      } else {
        s.snake.pop();
      }

      // Render onto canvas
      render();
    }, stateRef.current.speed);

    return () => clearInterval(timer);
  }, [status, highScore, settings.soundEnabled, spawnFood]);

  const render = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const s = stateRef.current;
    const width = GRID_SIZE * CELL_SIZE;
    const height = GRID_SIZE * CELL_SIZE;

    // Background
    ctx.fillStyle = '#090d16';
    ctx.fillRect(0, 0, width, height);

    // Grid lines
    ctx.strokeStyle = 'rgba(30, 41, 59, 0.4)';
    ctx.lineWidth = 1;
    for (let x = 0; x <= width; x += CELL_SIZE) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, height);
      ctx.stroke();
    }
    for (let y = 0; y <= height; y += CELL_SIZE) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
      ctx.stroke();
    }

    // Food
    ctx.beginPath();
    ctx.arc(
      s.food.x * CELL_SIZE + CELL_SIZE / 2,
      s.food.y * CELL_SIZE + CELL_SIZE / 2,
      CELL_SIZE / 2.6,
      0,
      Math.PI * 2
    );
    ctx.fillStyle = '#10b981';
    ctx.shadowColor = '#34d399';
    ctx.shadowBlur = 10;
    ctx.fill();
    ctx.shadowBlur = 0;

    // Snake Body
    s.snake.forEach((seg, index) => {
      const isHead = index === 0;
      ctx.fillStyle = isHead ? '#38bdf8' : '#0284c7';
      if (isHead) {
        ctx.shadowColor = '#38bdf8';
        ctx.shadowBlur = 10;
      }
      ctx.fillRect(seg.x * CELL_SIZE + 1.5, seg.y * CELL_SIZE + 1.5, CELL_SIZE - 3, CELL_SIZE - 3);
      ctx.shadowBlur = 0;
    });
  };

  // Initial draw
  useEffect(() => {
    render();
  }, []);

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      switch (e.key) {
        case 'ArrowUp':
        case 'w':
        case 'W':
          e.preventDefault();
          changeDirection(0, -1);
          break;
        case 'ArrowDown':
        case 's':
        case 'S':
          e.preventDefault();
          changeDirection(0, 1);
          break;
        case 'ArrowLeft':
        case 'a':
        case 'A':
          e.preventDefault();
          changeDirection(-1, 0);
          break;
        case 'ArrowRight':
        case 'd':
        case 'D':
          e.preventDefault();
          changeDirection(1, 0);
          break;
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [changeDirection]);

  return (
    <div className="flex flex-col items-center w-full max-w-md mx-auto" id="cyber-snake-container">
      {/* Top Bar */}
      <div className="w-full flex items-center justify-between px-3 py-2 bg-slate-900/90 border border-slate-800 rounded-t-xl text-slate-200">
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400 font-medium">得分</span>
          <span className="text-xl font-bold text-emerald-400 font-mono leading-none">{score}</span>
        </div>
        <div className="flex items-center gap-1.5 px-2.5 py-1 bg-slate-800 rounded-lg text-xs font-medium text-slate-300">
          <Trophy className="w-3.5 h-3.5 text-yellow-400" />
          <span className="font-mono">{highScore}</span>
        </div>
      </div>

      {/* Main Canvas View */}
      <div className="relative w-full aspect-square bg-slate-950 border-x border-slate-800 overflow-hidden flex items-center justify-center">
        <canvas
          ref={canvasRef}
          width={GRID_SIZE * CELL_SIZE}
          height={GRID_SIZE * CELL_SIZE}
          className="w-full h-full max-w-[360px] max-h-[360px]"
        />

        {status === 'idle' && (
          <div className="absolute inset-0 bg-slate-950/85 backdrop-blur-sm flex flex-col items-center justify-center p-6 text-center">
            <div className="w-12 h-12 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center mb-3 text-emerald-400">
              <Sparkles className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-white mb-1">霓虹貪吃蛇</h3>
            <p className="text-xs text-slate-300 mb-5 max-w-xs">
              吃光綠色能量球，注意別撞到自己的身體或牆壁！
            </p>
            <button
              onClick={startGame}
              className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold rounded-xl flex items-center gap-2 shadow-lg shadow-emerald-600/25 active:scale-95 transition-all"
            >
              <Play className="w-4 h-4 fill-white" />
              開始遊戲
            </button>
          </div>
        )}

        {status === 'gameover' && (
          <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-md flex flex-col items-center justify-center p-6 text-center">
            <h3 className="text-xl font-bold text-rose-400 mb-2">撞牆 Game Over！</h3>
            <p className="text-sm font-mono text-slate-300 mb-4">得分: {score}</p>
            <button
              onClick={startGame}
              className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold rounded-xl flex items-center gap-2 transition-all active:scale-95"
            >
              <RotateCcw className="w-4 h-4" />
              重新開始
            </button>
          </div>
        )}
      </div>

      {/* D-Pad controls for Mobile */}
      <div className="w-full p-3 bg-slate-900/95 border border-slate-800 rounded-b-xl flex flex-col items-center gap-1.5">
        <button
          onClick={() => changeDirection(0, -1)}
          className="w-12 h-10 bg-slate-800 hover:bg-slate-700 active:bg-sky-600 border border-slate-700 rounded-lg flex items-center justify-center text-slate-200"
        >
          <ArrowUp className="w-5 h-5" />
        </button>
        <div className="flex items-center gap-3">
          <button
            onClick={() => changeDirection(-1, 0)}
            className="w-12 h-10 bg-slate-800 hover:bg-slate-700 active:bg-sky-600 border border-slate-700 rounded-lg flex items-center justify-center text-slate-200"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <button
            onClick={() => changeDirection(0, 1)}
            className="w-12 h-10 bg-slate-800 hover:bg-slate-700 active:bg-sky-600 border border-slate-700 rounded-lg flex items-center justify-center text-slate-200"
          >
            <ArrowDown className="w-5 h-5" />
          </button>
          <button
            onClick={() => changeDirection(1, 0)}
            className="w-12 h-10 bg-slate-800 hover:bg-slate-700 active:bg-sky-600 border border-slate-700 rounded-lg flex items-center justify-center text-slate-200"
          >
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
};
