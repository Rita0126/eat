import React, { useEffect, useRef, useState, useCallback } from 'react';
import { soundManager } from '../utils/audio';
import confetti from 'canvas-confetti';
import { Play, RotateCcw, Volume2, VolumeX, Shield, Zap, Trophy, Award, Sparkles, ArrowLeft, ArrowRight } from 'lucide-react';
import type { GameSettings, GameStatus } from '../types';

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  alpha: number;
  decay: number;
}

interface Item {
  x: number;
  y: number;
  radius: number;
  speed: number;
  type: 'meteor' | 'crystal' | 'shield';
  rotation: number;
  rotationSpeed: number;
  points?: number;
}

interface NeonDodgerProps {
  settings: GameSettings;
  onUpdateSettings?: (settings: Partial<GameSettings>) => void;
}

export const NeonDodgerGame: React.FC<NeonDodgerProps> = ({ settings, onUpdateSettings }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [status, setStatus] = useState<GameStatus>('idle');
  const [score, setScore] = useState(0);
  const [highScore, setHighScore] = useState(() => {
    return parseInt(localStorage.getItem('vibe_dodger_highscore') || '0', 10);
  });
  const [level, setLevel] = useState(1);
  const [hasShield, setHasShield] = useState(false);
  const [combo, setCombo] = useState(0);
  const [newHighRecord, setNewHighRecord] = useState(false);

  // Game internal state ref to prevent stale closures in requestAnimationFrame
  const stateRef = useRef({
    status: 'idle' as GameStatus,
    player: {
      x: 200,
      y: 460,
      width: 32,
      height: 42,
      targetX: 200,
      speed: 8,
      shield: false,
    },
    items: [] as Item[],
    particles: [] as Particle[],
    lastSpawn: 0,
    spawnInterval: 700,
    score: 0,
    level: 1,
    combo: 0,
    comboTimer: 0,
    keys: { left: false, right: false },
    canvasWidth: 400,
    canvasHeight: 520,
  });

  // Handle High Score persistence
  const updateHighScore = useCallback((finalScore: number) => {
    if (finalScore > highScore) {
      setHighScore(finalScore);
      setNewHighRecord(true);
      localStorage.setItem('vibe_dodger_highscore', finalScore.toString());
      confetti({
        particleCount: 80,
        spread: 60,
        origin: { y: 0.6 },
      });
    }
  }, [highScore]);

  // Restart game
  const startGame = () => {
    const s = stateRef.current;
    s.status = 'playing';
    s.player.x = s.canvasWidth / 2;
    s.player.targetX = s.canvasWidth / 2;
    s.player.shield = false;
    s.items = [];
    s.particles = [];
    s.score = 0;
    s.level = 1;
    s.combo = 0;
    s.spawnInterval = 750;
    setScore(0);
    setLevel(1);
    setHasShield(false);
    setCombo(0);
    setNewHighRecord(false);
    setStatus('playing');

    soundManager.playJump(settings.soundEnabled);
    if (settings.musicEnabled) {
      soundManager.startBGM(true);
    }
  };

  const pauseGame = () => {
    if (status === 'playing') {
      setStatus('paused');
      stateRef.current.status = 'paused';
    } else if (status === 'paused') {
      setStatus('playing');
      stateRef.current.status = 'playing';
    }
  };

  // Canvas loop & game physics
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let lastTime = performance.now();

    const spawnItem = (now: number) => {
      const s = stateRef.current;
      if (now - s.lastSpawn < s.spawnInterval) return;
      s.lastSpawn = now;

      const rand = Math.random();
      const x = 20 + Math.random() * (s.canvasWidth - 40);
      const baseSpeed = 2.2 + s.level * 0.45;

      if (rand < 0.12 && !s.player.shield) {
        // Shield power-up
        s.items.push({
          x,
          y: -20,
          radius: 12,
          speed: baseSpeed * 0.9,
          type: 'shield',
          rotation: 0,
          rotationSpeed: 0.04,
          points: 50,
        });
      } else if (rand < 0.42) {
        // Energy Crystal
        s.items.push({
          x,
          y: -20,
          radius: 10,
          speed: baseSpeed * 1.1,
          type: 'crystal',
          rotation: 0,
          rotationSpeed: 0.06,
          points: 25,
        });
      } else {
        // Meteor Obstacle
        const size = 14 + Math.random() * 12;
        s.items.push({
          x,
          y: -20,
          radius: size,
          speed: baseSpeed + (Math.random() * 0.8),
          type: 'meteor',
          rotation: Math.random() * Math.PI,
          rotationSpeed: (Math.random() - 0.5) * 0.08,
        });
      }

      // Dynamic difficulty adjustment
      s.spawnInterval = Math.max(320, 750 - (s.level * 35));
    };

    const addExplosion = (x: number, y: number, color: string, count = 16) => {
      for (let i = 0; i < count; i++) {
        const angle = Math.random() * Math.PI * 2;
        const speed = 1 + Math.random() * 4;
        stateRef.current.particles.push({
          x,
          y,
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed,
          size: 2 + Math.random() * 3,
          color,
          alpha: 1,
          decay: 0.02 + Math.random() * 0.03,
        });
      }
    };

    const render = (time: number) => {
      const dt = Math.min((time - lastTime) / 1000, 0.1);
      lastTime = time;
      const s = stateRef.current;

      // Clear with subtle trail
      ctx.fillStyle = '#090d16';
      ctx.fillRect(0, 0, s.canvasWidth, s.canvasHeight);

      // Draw starry space grid backdrop
      ctx.fillStyle = 'rgba(255, 255, 255, 0.08)';
      for (let i = 0; i < 25; i++) {
        const starX = (Math.sin(i * 99 + time * 0.0005) * 0.5 + 0.5) * s.canvasWidth;
        const starY = (Math.cos(i * 33 + time * 0.0002) * 0.5 + 0.5) * s.canvasHeight;
        ctx.fillRect(starX, starY, 1.5, 1.5);
      }

      // Update in playing state
      if (s.status === 'playing') {
        // Player keyboard motion
        if (s.keys.left) {
          s.player.x -= s.player.speed;
        }
        if (s.keys.right) {
          s.player.x += s.player.speed;
        }

        // Smooth movement clamping
        s.player.x = Math.max(s.player.width / 2 + 8, Math.min(s.canvasWidth - s.player.width / 2 - 8, s.player.x));

        spawnItem(time);

        // Update items
        for (let i = s.items.length - 1; i >= 0; i--) {
          const item = s.items[i];
          item.y += item.speed;
          item.rotation += item.rotationSpeed;

          // Check collision with player
          const dx = item.x - s.player.x;
          const dy = item.y - s.player.y;
          const dist = Math.sqrt(dx * dx + dy * dy);

          if (dist < item.radius + s.player.width / 2.2) {
            // Collision detected!
            if (item.type === 'meteor') {
              if (s.player.shield) {
                // Shield absorbs damage!
                s.player.shield = false;
                setHasShield(false);
                addExplosion(item.x, item.y, '#38bdf8', 20);
                soundManager.playHit(settings.soundEnabled);
                s.items.splice(i, 1);
                continue;
              } else {
                // Game Over
                s.status = 'gameover';
                setStatus('gameover');
                soundManager.stopBGM();
                soundManager.playGameOver(settings.soundEnabled);
                addExplosion(s.player.x, s.player.y, '#f43f5e', 35);
                updateHighScore(s.score);
                break;
              }
            } else if (item.type === 'crystal') {
              // Collected energy crystal!
              s.score += (item.points || 25) * (1 + Math.floor(s.combo / 4));
              s.combo += 1;
              setScore(s.score);
              setCombo(s.combo);
              addExplosion(item.x, item.y, '#34d399', 12);
              soundManager.playCollect(settings.soundEnabled);

              // Check Level Progression
              const nextLevel = 1 + Math.floor(s.score / 180);
              if (nextLevel > s.level) {
                s.level = nextLevel;
                setLevel(nextLevel);
                soundManager.playLevelUp(settings.soundEnabled);
              }

              s.items.splice(i, 1);
              continue;
            } else if (item.type === 'shield') {
              // Collected shield powerup!
              s.player.shield = true;
              setHasShield(true);
              s.score += 50;
              setScore(s.score);
              addExplosion(item.x, item.y, '#38bdf8', 16);
              soundManager.playJump(settings.soundEnabled);
              s.items.splice(i, 1);
              continue;
            }
          }

          // Off screen
          if (item.y > s.canvasHeight + 30) {
            if (item.type === 'meteor') {
              // Successfully dodged meteor!
              s.score += 5;
              setScore(s.score);
            }
            s.items.splice(i, 1);
          }
        }
      }

      // Draw items
      s.items.forEach((item) => {
        ctx.save();
        ctx.translate(item.x, item.y);
        ctx.rotate(item.rotation);

        if (item.type === 'meteor') {
          // Fiery Meteor
          ctx.beginPath();
          ctx.arc(0, 0, item.radius, 0, Math.PI * 2);
          ctx.fillStyle = '#ef4444';
          ctx.fill();
          ctx.strokeStyle = '#f97316';
          ctx.lineWidth = 3;
          ctx.stroke();

          // Core crater
          ctx.beginPath();
          ctx.arc(-item.radius * 0.3, -item.radius * 0.3, item.radius * 0.28, 0, Math.PI * 2);
          ctx.fillStyle = '#991b1b';
          ctx.fill();
        } else if (item.type === 'crystal') {
          // Glowing Diamond
          ctx.beginPath();
          ctx.moveTo(0, -item.radius * 1.3);
          ctx.lineTo(item.radius, 0);
          ctx.moveTo(0, item.radius * 1.3);
          ctx.lineTo(-item.radius, 0);
          ctx.closePath();
          ctx.fillStyle = '#10b981';
          ctx.shadowColor = '#34d399';
          ctx.shadowBlur = 10;
          ctx.fill();
          ctx.strokeStyle = '#a7f3d0';
          ctx.lineWidth = 2;
          ctx.stroke();
        } else if (item.type === 'shield') {
          // Shield Orb
          ctx.beginPath();
          ctx.arc(0, 0, item.radius, 0, Math.PI * 2);
          ctx.fillStyle = '#0284c7';
          ctx.shadowColor = '#38bdf8';
          ctx.shadowBlur = 14;
          ctx.fill();
          ctx.strokeStyle = '#bae6fd';
          ctx.lineWidth = 2.5;
          ctx.stroke();
        }
        ctx.restore();
      });

      // Update & draw particles
      for (let i = s.particles.length - 1; i >= 0; i--) {
        const p = s.particles[i];
        p.x += p.vx;
        p.y += p.vy;
        p.alpha -= p.decay;

        if (p.alpha <= 0) {
          s.particles.splice(i, 1);
          continue;
        }

        ctx.save();
        ctx.globalAlpha = p.alpha;
        ctx.fillStyle = p.color;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }

      // Draw Spaceship Player (if not gameover)
      if (s.status !== 'gameover') {
        ctx.save();
        ctx.translate(s.player.x, s.player.y);

        // Rocket booster thruster flame
        if (s.status === 'playing') {
          ctx.beginPath();
          ctx.moveTo(-6, s.player.height * 0.4);
          ctx.lineTo(0, s.player.height * 0.4 + 10 + Math.random() * 6);
          ctx.lineTo(6, s.player.height * 0.4);
          ctx.fillStyle = '#f59e0b';
          ctx.fill();
        }

        // Spaceship Body
        ctx.beginPath();
        ctx.moveTo(0, -s.player.height * 0.5);
        ctx.lineTo(s.player.width * 0.5, s.player.height * 0.4);
        ctx.lineTo(0, s.player.height * 0.25);
        ctx.lineTo(-s.player.width * 0.5, s.player.height * 0.4);
        ctx.closePath();

        ctx.fillStyle = settings.playerColor || '#38bdf8';
        ctx.shadowColor = '#0284c7';
        ctx.shadowBlur = 12;
        ctx.fill();
        ctx.strokeStyle = '#e0f2fe';
        ctx.lineWidth = 2;
        ctx.stroke();

        // Cockpit window
        ctx.beginPath();
        ctx.ellipse(0, -4, 4, 8, 0, 0, Math.PI * 2);
        ctx.fillStyle = '#ffffff';
        ctx.fill();

        // Shield Bubble
        if (s.player.shield) {
          ctx.beginPath();
          ctx.arc(0, 0, s.player.width * 0.9, 0, Math.PI * 2);
          ctx.strokeStyle = 'rgba(56, 189, 248, 0.8)';
          ctx.lineWidth = 3;
          ctx.shadowColor = '#38bdf8';
          ctx.shadowBlur = 16;
          ctx.stroke();
          ctx.fillStyle = 'rgba(56, 189, 248, 0.15)';
          ctx.fill();
        }

        ctx.restore();
      }

      animId = requestAnimationFrame(render);
    };

    animId = requestAnimationFrame(render);

    return () => {
      cancelAnimationFrame(animId);
      soundManager.stopBGM();
    };
  }, [settings.soundEnabled, settings.musicEnabled, settings.playerColor, status, updateHighScore]);

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowLeft' || e.key === 'a' || e.key === 'A') {
        stateRef.current.keys.left = true;
      }
      if (e.key === 'ArrowRight' || e.key === 'd' || e.key === 'D') {
        stateRef.current.keys.right = true;
      }
      if (e.key === ' ' && status === 'playing') {
        e.preventDefault();
        pauseGame();
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      if (e.key === 'ArrowLeft' || e.key === 'a' || e.key === 'A') {
        stateRef.current.keys.left = false;
      }
      if (e.key === 'ArrowRight' || e.key === 'd' || e.key === 'D') {
        stateRef.current.keys.right = false;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [status]);

  // Touch / Pointer controls on canvas
  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (status !== 'playing') return;
    const rect = e.currentTarget.getBoundingClientRect();
    const scaleX = 400 / rect.width;
    const x = (e.clientX - rect.left) * scaleX;
    stateRef.current.player.x = Math.max(24, Math.min(376, x));
  };

  return (
    <div className="flex flex-col items-center w-full max-w-md mx-auto" id="neon-dodger-container">
      {/* Top Game Bar */}
      <div className="w-full flex items-center justify-between px-3 py-2 bg-slate-900/90 border border-slate-800 rounded-t-xl text-slate-200">
        <div className="flex items-center gap-3">
          <div className="flex flex-col">
            <span className="text-xs text-slate-400 font-medium">當前得分</span>
            <span className="text-xl font-bold text-amber-400 font-mono leading-none">{score}</span>
          </div>
          {combo > 1 && (
            <span className="px-2 py-0.5 bg-amber-500/20 text-amber-300 border border-amber-500/40 rounded-full text-xs font-mono font-bold animate-pulse">
              {combo}x 連擊
            </span>
          )}
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 px-2.5 py-1 bg-slate-800 rounded-lg text-xs font-medium text-slate-300">
            <Trophy className="w-3.5 h-3.5 text-yellow-400" />
            <span className="font-mono">{highScore}</span>
          </div>
          <div className="px-2 py-1 bg-sky-950/70 border border-sky-800 text-sky-300 rounded text-xs font-mono">
            LV.{level}
          </div>
        </div>
      </div>

      {/* Main Canvas Frame */}
      <div className="relative w-full aspect-[400/520] bg-slate-950 border-x border-slate-800 overflow-hidden select-none">
        <canvas
          ref={canvasRef}
          width={400}
          height={520}
          onPointerMove={handlePointerMove}
          className="w-full h-full cursor-crosshair touch-none"
        />

        {/* Floating Active Buffs */}
        {hasShield && status === 'playing' && (
          <div className="absolute top-3 left-3 flex items-center gap-1.5 px-2.5 py-1 bg-sky-500/20 border border-sky-400 text-sky-200 rounded-full text-xs font-medium backdrop-blur-sm">
            <Shield className="w-3.5 h-3.5 text-sky-400" />
            <span>護盾啟動中</span>
          </div>
        )}

        {/* Start / Idle Overlay */}
        {status === 'idle' && (
          <div className="absolute inset-0 bg-slate-950/85 backdrop-blur-sm flex flex-col items-center justify-center p-6 text-center">
            <div className="w-14 h-14 rounded-2xl bg-sky-500/10 border border-sky-500/30 flex items-center justify-center mb-3 text-sky-400">
              <Sparkles className="w-7 h-7" />
            </div>
            <h3 className="text-xl font-bold text-white mb-1">霓虹星際穿梭</h3>
            <p className="text-xs text-slate-300 mb-6 max-w-xs leading-relaxed">
              控制太空梭穿梭星海！左右閃避危險隕石、收集綠色能量水晶與藍色防護盾。
            </p>

            <button
              id="btn-start-dodger"
              onClick={startGame}
              className="px-6 py-3 bg-gradient-to-r from-sky-500 to-indigo-600 hover:from-sky-400 hover:to-indigo-500 text-white font-semibold rounded-xl shadow-lg shadow-sky-500/25 flex items-center gap-2 transition-all active:scale-95"
            >
              <Play className="w-4 h-4 fill-white" />
              開始冒險
            </button>

            <div className="mt-6 flex items-center gap-4 text-[11px] text-slate-400">
              <span className="flex items-center gap-1">
                <kbd className="px-1.5 py-0.5 bg-slate-800 rounded border border-slate-700 font-mono">←</kbd>
                <kbd className="px-1.5 py-0.5 bg-slate-800 rounded border border-slate-700 font-mono">→</kbd> 或滑動控制
              </span>
            </div>
          </div>
        )}

        {/* Game Over Overlay */}
        {status === 'gameover' && (
          <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-md flex flex-col items-center justify-center p-6 text-center animate-in fade-in duration-200">
            <div className="w-14 h-14 rounded-2xl bg-rose-500/10 border border-rose-500/30 flex items-center justify-center mb-2 text-rose-400">
              <Award className="w-7 h-7" />
            </div>
            <h3 className="text-2xl font-black text-rose-400 mb-1">撞擊損毀！</h3>
            <p className="text-xs text-slate-400 mb-4">太空梭已失去訊號</p>

            <div className="w-full max-w-xs bg-slate-900 border border-slate-800 rounded-xl p-3.5 mb-5 flex justify-around">
              <div className="flex flex-col items-center">
                <span className="text-[11px] text-slate-400 font-medium">本次得分</span>
                <span className="text-2xl font-bold font-mono text-white">{score}</span>
              </div>
              <div className="w-px bg-slate-800" />
              <div className="flex flex-col items-center">
                <span className="text-[11px] text-slate-400 font-medium">歷史最高</span>
                <span className="text-2xl font-bold font-mono text-amber-400">{highScore}</span>
              </div>
            </div>

            {newHighRecord && (
              <p className="text-xs font-semibold text-emerald-400 mb-4 animate-bounce flex items-center gap-1">
                🎉 突破個人最佳紀錄！
              </p>
            )}

            <button
              id="btn-restart-dodger"
              onClick={startGame}
              className="px-6 py-3 bg-gradient-to-r from-sky-500 to-indigo-600 hover:from-sky-400 hover:to-indigo-500 text-white font-semibold rounded-xl shadow-lg shadow-sky-500/25 flex items-center gap-2 transition-all active:scale-95"
            >
              <RotateCcw className="w-4 h-4" />
              重新挑戰
            </button>
          </div>
        )}
      </div>

      {/* Mobile Touch Navigation Controls */}
      <div className="w-full p-2.5 bg-slate-900/95 border border-slate-800 rounded-b-xl flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <button
            onPointerDown={() => { stateRef.current.keys.left = true; }}
            onPointerUp={() => { stateRef.current.keys.left = false; }}
            onPointerLeave={() => { stateRef.current.keys.left = false; }}
            className="w-12 h-11 bg-slate-800 hover:bg-slate-700 active:bg-sky-600 border border-slate-700 rounded-lg flex items-center justify-center text-slate-200 transition-colors"
            title="向左移動"
            aria-label="Move left"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <button
            onPointerDown={() => { stateRef.current.keys.right = true; }}
            onPointerUp={() => { stateRef.current.keys.right = false; }}
            onPointerLeave={() => { stateRef.current.keys.right = false; }}
            className="w-12 h-11 bg-slate-800 hover:bg-slate-700 active:bg-sky-600 border border-slate-700 rounded-lg flex items-center justify-center text-slate-200 transition-colors"
            title="向右移動"
            aria-label="Move right"
          >
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>

        {/* Sound Controls */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => onUpdateSettings?.({ soundEnabled: !settings.soundEnabled })}
            className={`p-2 rounded-lg border text-xs font-medium flex items-center gap-1.5 transition-colors ${
              settings.soundEnabled
                ? 'bg-slate-800 border-slate-700 text-slate-200'
                : 'bg-slate-900 border-slate-800 text-slate-500'
            }`}
            title="音效開關"
          >
            {settings.soundEnabled ? <Volume2 className="w-4 h-4 text-emerald-400" /> : <VolumeX className="w-4 h-4" />}
            <span>音效</span>
          </button>

          {status === 'playing' && (
            <button
              onClick={pauseGame}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 rounded-lg text-xs font-medium"
            >
              暫停
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
