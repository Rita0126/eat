import React from 'react';
import { Volume2, VolumeX, Music, Sliders, Palette, Zap } from 'lucide-react';
import type { GameSettings } from '../types';

interface GameCustomizerProps {
  settings: GameSettings;
  onChange: (newSettings: Partial<GameSettings>) => void;
}

const COLOR_PRESETS = [
  { name: '霓虹青藍', value: '#38bdf8' },
  { name: '激光粉紫', value: '#ec4899' },
  { name: '電漿翠綠', value: '#10b981' },
  { name: '曜石金黃', value: '#f59e0b' },
  { name: '狂暴赤紅', value: '#f43f5e' },
];

export const GameCustomizer: React.FC<GameCustomizerProps> = ({ settings, onChange }) => {
  return (
    <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-4 text-xs text-slate-200">
      <div className="flex items-center gap-2 font-semibold text-slate-100 text-sm">
        <Sliders className="w-4 h-4 text-sky-400" />
        <span>即時自然語言/參數微調區</span>
      </div>

      {/* Color Customizer */}
      <div>
        <label className="flex items-center gap-1.5 text-slate-400 mb-2 font-medium">
          <Palette className="w-3.5 h-3.5 text-slate-400" />
          <span>太空梭機體配色 (微調視覺風格)</span>
        </label>
        <div className="flex flex-wrap items-center gap-2">
          {COLOR_PRESETS.map((color) => (
            <button
              key={color.value}
              onClick={() => onChange({ playerColor: color.value })}
              className={`px-2.5 py-1 rounded-lg border text-xs flex items-center gap-1.5 transition-all ${
                settings.playerColor === color.value
                  ? 'border-white bg-slate-800 text-white shadow'
                  : 'border-slate-800 bg-slate-950/60 text-slate-400 hover:text-slate-200'
              }`}
            >
              <span
                className="w-2.5 h-2.5 rounded-full"
                style={{ backgroundColor: color.value }}
              />
              <span>{color.name}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Toggles */}
      <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-800">
        <button
          onClick={() => onChange({ soundEnabled: !settings.soundEnabled })}
          className={`p-2 rounded-lg border flex items-center justify-between transition-colors ${
            settings.soundEnabled
              ? 'bg-emerald-950/40 border-emerald-800 text-emerald-300'
              : 'bg-slate-950 border-slate-800 text-slate-500'
          }`}
        >
          <div className="flex items-center gap-1.5">
            {settings.soundEnabled ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
            <span>8-bit 碰撞音效</span>
          </div>
          <span className="font-mono text-[10px]">{settings.soundEnabled ? 'ON' : 'OFF'}</span>
        </button>

        <button
          onClick={() => onChange({ musicEnabled: !settings.musicEnabled })}
          className={`p-2 rounded-lg border flex items-center justify-between transition-colors ${
            settings.musicEnabled
              ? 'bg-sky-950/40 border-sky-800 text-sky-300'
              : 'bg-slate-950 border-slate-800 text-slate-500'
          }`}
        >
          <div className="flex items-center gap-1.5">
            <Music className="w-3.5 h-3.5" />
            <span>合成節奏背景音</span>
          </div>
          <span className="font-mono text-[10px]">{settings.musicEnabled ? 'ON' : 'OFF'}</span>
        </button>
      </div>
    </div>
  );
};
