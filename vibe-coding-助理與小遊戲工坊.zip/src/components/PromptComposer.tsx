import React, { useState } from 'react';
import { Sparkles, Copy, Check, MessageSquareCode } from 'lucide-react';

interface PromptComposerProps {
  initialPrompt?: string;
}

export const PromptComposer: React.FC<PromptComposerProps> = ({ initialPrompt = '' }) => {
  const [ideaText, setIdeaText] = useState(initialPrompt);
  const [copied, setCopied] = useState(false);

  // Sync if initial prompt changes from outside
  React.useEffect(() => {
    if (initialPrompt) {
      setIdeaText(initialPrompt);
    }
  }, [initialPrompt]);

  const generateFullPrompt = () => {
    const core = ideaText.trim() || '一個簡單直覺的休閒小遊戲';
    return `你現在是我的 Vibe Coding 操作助理。我想做：${core}。

請嚴格遵循第一階段規範：
1. 使用 Next.js / React / TypeScript / Tailwind CSS 實作。
2. 遊戲必須成形：具備明確玩法規則、計分機制、開始/結束/重新開始畫面。
3. 加入合成音效回饋，並支援電腦鍵盤與手機觸控操作。
4. 撰寫乾淨代碼並通過 build，讓我能直接試玩。`;
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(generateFullPrompt());
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-3" id="prompt-composer">
      <div className="flex items-center gap-2 text-sm font-semibold text-white">
        <MessageSquareCode className="w-4 h-4 text-sky-400" />
        <span>自訂小遊戲提示詞產生器 (給 Agent)</span>
      </div>

      <p className="text-xs text-slate-400">
        輸入你的小遊戲點子，或點擊上方靈感庫，自動包裝成符合「第一階段」標準的提示詞：
      </p>

      <textarea
        value={ideaText}
        onChange={(e) => setIdeaText(e.target.value)}
        placeholder="例如：我想做一個躲避冰雹的企鵝，或是 30 秒限時打地鼠..."
        rows={3}
        className="w-full p-3 rounded-lg bg-slate-950 border border-slate-800 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-sky-500 transition-colors"
      />

      <div className="flex items-center justify-between pt-1">
        <span className="text-[11px] text-slate-400">
          包含 Next.js、TypeScript、音效、手機適配與成果優先規範
        </span>
        <button
          onClick={handleCopy}
          className="px-4 py-2 bg-sky-600 hover:bg-sky-500 active:scale-95 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all shadow-md shadow-sky-600/20"
        >
          {copied ? (
            <>
              <Check className="w-3.5 h-3.5 text-emerald-300" />
              <span>已複製提示詞</span>
            </>
          ) : (
            <>
              <Copy className="w-3.5 h-3.5" />
              <span>複製完整提示詞</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
};
