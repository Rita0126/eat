import React, { useState } from 'react';
import { 
  CheckCircle2, 
  Circle, 
  ExternalLink, 
  Copy, 
  Check, 
  ShieldAlert, 
  Terminal, 
  Sparkles, 
  ArrowRight,
  Code2,
  Gamepad2,
  Rocket,
  Lightbulb
} from 'lucide-react';
import type { VibeStep } from '../types';

interface WorkflowGuideProps {
  onSelectGamePrompt: (promptText: string) => void;
}

const INITIAL_STEPS: VibeStep[] = [
  {
    id: 'step-a',
    stepLetter: 'A',
    title: '基礎環境確認',
    description: '快速確認電腦具備 VS Code、Git、Node.js 與 GitHub 帳號。',
    category: 'env',
    status: 'completed',
    actionUrl: 'https://code.visualstudio.com/',
    actionUrlLabel: 'VS Code 官網下載',
    notes: '正常就繼續，已有且可用的工具不需重裝。接著在 VS Code 登入 GitHub，開啟 Copilot/Agent 模式。',
  },
  {
    id: 'step-b',
    stepLetter: 'B',
    title: 'Agent 補齊開發插件',
    description: '讓 Agent 自行補齊繁中語言包、Tailwind IntelliSense、Prettier、GitLens 等。',
    category: 'env',
    status: 'completed',
    command: 'code --install-extension MS-CEINTL.vscode-language-pack-zh-hant && code --install-extension bradlc.vscode-tailwindcss',
    notes: 'Agent 能做的低風險工作交給 Agent，不需要手動記憶繁雜安裝指令。',
  },
  {
    id: 'step-c',
    stepLetter: 'C',
    title: '構想簡單小遊戲',
    description: '回答「你想做什麼簡單的小遊戲？」避免第一次做多人連線或大型 3D。',
    category: 'code',
    status: 'in_progress',
    notes: '點子由你決定！推薦：星際穿梭避障、復古貪吃蛇、節奏點擊、翻牌對對碰。',
  },
  {
    id: 'step-d',
    stepLetter: 'D',
    title: 'Agent 建立正式專案',
    description: '使用 Next.js、React、TypeScript、App Router、Tailwind CSS 建立專案。',
    category: 'code',
    status: 'in_progress',
    notes: '不用事先全域安裝，由 Agent 自行安裝依賴、配置 tailwind 與編寫基礎結構。',
  },
  {
    id: 'step-e',
    stepLetter: 'E',
    title: '遊戲成形與體驗完整',
    description: '必須具備：明確規則、開始/重玩、計分、關卡、合成音效、手機觸控支援。',
    category: 'code',
    status: 'completed',
    notes: '當前預覽區已包含符合標準的星際避障與貪吃蛇原型，可隨時切換試玩！',
  },
  {
    id: 'step-f',
    stepLetter: 'F',
    title: '試玩與自然語言微調',
    description: '親自試玩，用日常口語告訴 Agent 哪裡需要修改（例如「速度調慢一點」）。',
    category: 'code',
    status: 'pending',
    notes: '反覆調整直到體驗順暢、無報錯。',
  },
  {
    id: 'step-g',
    stepLetter: 'G',
    title: '資安檢查與 GitHub 發布',
    description: '確認 .gitignore 無金鑰外洩，初始化 Git 儲存庫並推送到 GitHub。',
    category: 'publish',
    status: 'pending',
    command: 'git init && git add . && git commit -m "feat: 初版小遊戲完成" && gh repo create --public --source=. --push',
    notes: '秘密與 API Key 絕不貼入聊天或推送至公開 GitHub Repo。',
  },
  {
    id: 'step-h',
    stepLetter: 'H',
    title: 'Vercel CLI 部署取得公開網址',
    description: '執行 Vercel 部署，取得朋友打開就能立刻玩的正式網址。',
    category: 'publish',
    status: 'pending',
    actionUrl: 'https://vercel.com/new',
    actionUrlLabel: 'Vercel 官方控制台',
    command: 'npx vercel --prod',
    notes: '完成標準：取得公開網址，朋友手機與電腦都能直接遊玩！',
  },
  {
    id: 'step-i',
    stepLetter: 'I',
    title: '驗證自動化 CI/CD 更新',
    description: '做一個肉眼可見的小修改（例如換色或加標籤），push 後確認 Vercel 自動更新。',
    category: 'publish',
    status: 'pending',
    notes: '無需手動重新部署，推送到 main 分支即自動觸發線上建置。',
  },
];

const GAME_IDEAS = [
  {
    title: '🚀 星際穿梭避障 (Neon Dodger)',
    desc: '左右滑動太空梭，躲避隕石、收集能源晶體與護盾，挑戰最高連擊分。',
    prompt: '我想做一個「星際穿梭避障」網頁遊戲，太空梭在下方左右移動避開掉落的隕石，可以吃能量球加分與收集護盾。請用 React + TypeScript + Tailwind CSS，並加入合成音效與手機觸控支援。',
  },
  {
    title: '🐍 賽博龐克貪吃蛇 (Cyber Snake)',
    desc: '經典網格玩法，加入特殊加速道具與霓虹流光特效，支援手機方向鍵盤。',
    prompt: '我想做一個霓虹風格的「貪吃蛇」小遊戲，具有計分、歷史最高分紀錄、吃食物音效與撞牆重來機制。手機版請提供虛擬方向按鈕。',
  },
  {
    title: '🎵 節奏拍點狂潮 (Rhythm Beat)',
    desc: '四軌落下光斑，在判定線點擊得分，累積 Perfect 連擊分數。',
    prompt: '我想做一個簡單的四軌節奏點擊遊戲，音符向下落，在判定線按下對應鍵或手機點擊，有 Perfect/Good/Miss 回饋與節奏音效。',
  },
  {
    title: '🎴 符號記憶翻牌 (Memory Match)',
    desc: '16 張洗牌卡片，兩兩翻開配對，考驗記憶力與步數計時器。',
    prompt: '我想做一個 4x4 符號記憶翻牌遊戲，點擊翻開兩張卡片，圖案相同就消除並播放成功音效，最後計算通關花費時間與步數。',
  },
];

export const VibeWorkflowGuide: React.FC<WorkflowGuideProps> = ({ onSelectGamePrompt }) => {
  const [steps, setSteps] = useState<VibeStep[]>(INITIAL_STEPS);
  const [copiedIndex, setCopiedIndex] = useState<string | null>(null);

  const toggleStep = (id: string) => {
    setSteps((prev) =>
      prev.map((step) => {
        if (step.id === id) {
          const nextStatus = step.status === 'completed' ? 'pending' : 'completed';
          return { ...step, status: nextStatus };
        }
        return step;
      })
    );
  };

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(id);
    setTimeout(() => setCopiedIndex(null), 1800);
  };

  const completedCount = steps.filter((s) => s.status === 'completed').length;
  const progressPercent = Math.round((completedCount / steps.length) * 100);

  return (
    <div className="w-full space-y-6 text-slate-100" id="vibe-workflow-guide">
      {/* Overview Banner */}
      <div className="p-5 rounded-2xl bg-gradient-to-r from-indigo-950/70 via-slate-900 to-sky-950/70 border border-slate-800 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-sky-500/10 border border-sky-500/20 text-sky-400 text-xs font-semibold mb-2">
              <Sparkles className="w-3.5 h-3.5" />
              第一階段：從零到第一個公開小遊戲
            </div>
            <h2 className="text-xl font-bold text-white tracking-tight">
              Vibe Coding 流程操作助理
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-xl leading-relaxed">
              想法 → VS Code Agent → 小遊戲 → Git/GitHub → Vercel → 公開網址。零程式門檻，工程細節交給 Agent 執行。
            </p>
          </div>

          <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-3 sm:text-right min-w-[150px]">
            <div className="flex items-center justify-between sm:justify-end gap-2 mb-1">
              <span className="text-xs text-slate-400 font-medium">第一階段進度</span>
              <span className="text-xs font-mono font-bold text-sky-400">{completedCount} / {steps.length}</span>
            </div>
            <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
              <div
                className="bg-gradient-to-r from-sky-500 to-indigo-500 h-full transition-all duration-300"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
            <span className="text-[11px] text-slate-400 mt-1 block">
              {progressPercent === 100 ? '🎉 第一階段完成，可以進入第二階段環境補強！' : '按部就班，成果優先'}
            </span>
          </div>
        </div>
      </div>

      {/* Recommended Game Ideas Picker */}
      <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800">
        <div className="flex items-center gap-2 mb-3">
          <Lightbulb className="w-5 h-5 text-amber-400" />
          <h3 className="text-sm font-semibold text-white">
            步驟 C 靈感庫：「你想做什麼簡單的小遊戲？」
          </h3>
        </div>
        <p className="text-xs text-slate-400 mb-4">
          第一次製作避免多人連線或大型 3D，選擇具備明確規則、分數與回饋的小遊戲最容易成功。點擊即可取得精準提示詞：
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {GAME_IDEAS.map((idea, idx) => (
            <div
              key={idx}
              className="p-3.5 bg-slate-900 border border-slate-800 hover:border-sky-500/40 rounded-xl transition-all flex flex-col justify-between group"
            >
              <div>
                <h4 className="text-xs font-bold text-slate-200 group-hover:text-sky-300 transition-colors">
                  {idea.title}
                </h4>
                <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">
                  {idea.desc}
                </p>
              </div>

              <div className="mt-3 flex items-center justify-between pt-2 border-t border-slate-800/80">
                <button
                  onClick={() => onSelectGamePrompt(idea.prompt)}
                  className="text-xs text-sky-400 hover:text-sky-300 flex items-center gap-1 font-medium transition-colors"
                >
                  <span>帶入提示詞</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => handleCopy(idea.prompt, `idea-${idx}`)}
                  className="p-1.5 hover:bg-slate-800 rounded text-slate-400 hover:text-slate-200 transition-colors"
                  title="複製提示詞"
                >
                  {copiedIndex === `idea-${idx}` ? (
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                  ) : (
                    <Copy className="w-3.5 h-3.5" />
                  )}
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 9-Step Roadmap Checklist */}
      <div className="space-y-3">
        <h3 className="text-sm font-semibold text-slate-300 flex items-center gap-2">
          <Gamepad2 className="w-4 h-4 text-sky-400" />
          <span>第一階段 A ~ I 執行清單</span>
        </h3>

        <div className="space-y-2.5">
          {steps.map((step) => {
            const isDone = step.status === 'completed';

            return (
              <div
                key={step.id}
                className={`p-4 rounded-xl border transition-all ${
                  isDone
                    ? 'bg-slate-900/40 border-slate-800/80 text-slate-400'
                    : 'bg-slate-900/90 border-slate-700/80 shadow-sm text-slate-200'
                }`}
              >
                <div className="flex items-start gap-3">
                  <button
                    onClick={() => toggleStep(step.id)}
                    className="mt-0.5 text-slate-400 hover:text-sky-400 transition-colors"
                    aria-label={`Toggle step ${step.stepLetter}`}
                  >
                    {isDone ? (
                      <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                    ) : (
                      <Circle className="w-5 h-5 text-slate-600" />
                    )}
                  </button>

                  <div className="flex-1 min-w-0">
                    <div className="flex flex-wrap items-center gap-2 mb-1">
                      <span className="w-5 h-5 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-[11px] font-mono font-bold text-sky-300">
                        {step.stepLetter}
                      </span>
                      <h4 className={`text-sm font-semibold ${isDone ? 'line-through text-slate-500' : 'text-slate-100'}`}>
                        {step.title}
                      </h4>
                    </div>

                    <p className="text-xs text-slate-300 leading-relaxed mb-2">
                      {step.description}
                    </p>

                    {step.notes && (
                      <p className="text-[11px] text-slate-400 bg-slate-950/60 rounded-lg p-2 border border-slate-800 mb-2">
                        💡 <span className="font-medium text-slate-300">助理備註：</span>{step.notes}
                      </p>
                    )}

                    {/* Official Link Action */}
                    {step.actionUrl && (
                      <div className="mt-2">
                        <a
                          href={step.actionUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1 text-xs text-sky-400 hover:text-sky-300 font-medium underline underline-offset-4"
                        >
                          <span>{step.actionUrlLabel || '官方操作頁面'}</span>
                          <ExternalLink className="w-3.5 h-3.5" />
                        </a>
                      </div>
                    )}

                    {/* Command Snippet */}
                    {step.command && (
                      <div className="mt-2.5 flex items-center justify-between gap-2 p-2 bg-slate-950 rounded-lg border border-slate-800 font-mono text-xs text-slate-300 overflow-x-auto">
                        <span className="truncate">{step.command}</span>
                        <button
                          onClick={() => handleCopy(step.command!, step.id)}
                          className="px-2 py-1 bg-slate-800 hover:bg-slate-700 rounded text-slate-300 text-[11px] flex items-center gap-1 shrink-0 transition-colors"
                        >
                          {copiedIndex === step.id ? (
                            <>
                              <Check className="w-3 h-3 text-emerald-400" />
                              <span className="text-emerald-400">已複製</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-3 h-3" />
                              <span>複製</span>
                            </>
                          )}
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Security Principles Banner */}
      <div className="p-4 rounded-xl bg-amber-950/20 border border-amber-800/40 flex items-start gap-3">
        <ShieldAlert className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
        <div className="text-xs text-amber-200/90 leading-relaxed">
          <strong className="text-amber-300 font-semibold block mb-0.5">資安與操作守則提醒 (原則 4)：</strong>
          登入、OAuth、密碼、API Key、Billing 敏感權限由本人在官方頁面確認；嚴禁將機密金鑰貼入對話或 Push 到公開 GitHub Repo。
        </div>
      </div>
    </div>
  );
};
