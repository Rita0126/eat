export type GameType = 'dodger' | 'snake' | 'rhythm';

export type GameStatus = 'idle' | 'playing' | 'paused' | 'gameover';

export interface GameSettings {
  soundEnabled: boolean;
  musicEnabled: boolean;
  difficulty: 'easy' | 'normal' | 'hard';
  playerColor: string;
}

export interface VibeStep {
  id: string;
  stepLetter: string;
  title: string;
  description: string;
  status: 'completed' | 'in_progress' | 'pending';
  category: 'env' | 'code' | 'publish';
  actionUrl?: string;
  actionUrlLabel?: string;
  command?: string;
  notes?: string;
}
