/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { NeonDodgerGame } from './components/NeonDodgerGame';
import { CyberSnakeGame } from './components/CyberSnakeGame';
import { VibeWorkflowGuide } from './components/VibeWorkflowGuide';
import { GameCustomizer } from './components/GameCustomizer';
import { PromptComposer } from './components/PromptComposer';
import { 
  Gamepad2, 
  ListOrdered, 
  Sparkles, 
  Rocket, 
  Terminal, 
  ExternalLink,
  Code2,
  CheckCircle,
  HelpCircle
} from 'lucide-react';
import type { GameSettings, GameType } from './types';

export default function App() {
  const [activeTab, setActiveTab] = useState<'game' | 'guide'>('game');
  const [selectedGame, setSelectedGame] = useState<GameType>('dodger');
  const [composerPrompt, setComposerPrompt] = useState<string>('');
  
  const [gameSettings, setGameSettings] = useState<GameSettings>({
    soundEnabled: true,
    musicEnabled: false,
    difficulty: 'normal',
    playerColor: '#38bdf8',
  });

  const handleUpdateSettings = (newSettings: Partial<GameSettings>) => {
    setGameSettings((prev) => ({ ...prev, ...newSettings }));
  };

  const handleSelectGamePrompt = (promptText: string) => {
    setComposerPrompt(promptText);
    setActiveTab('guide');
    // Scroll to prompt composer if needed
    const el = document.getElementById('prompt-composer');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col selection:bg-sky-500 selection:text-white">
      {/* Top Navigation Bar */}
      <header className="sticky top-0 z-30 w-full border-b border-slate-800 bg-slate-950/90 backdrop-blur-md">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-sky-500 to-indigo-600 flex items-center justify-center text-white shadow-md shadow-sky-500/20">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-sm sm:text-base font-bold text-white tracking-tight">
                  Vibe Coding 助理與小遊戲工坊
                </h1>
                <span className="hidden sm:inline-block px-2 py-0.5 text-[10px] font-semibold bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 rounded-full">
                  第一階段進行中
                </span>
              </div>
              <p className="text-[11px] text-slate-400 hidden xs:block">
                想法 → VS Code Agent → 小遊戲 → Git/GitHub → Vercel → 公開網址
              </p>
            </div>
          </div>

          {/* Tab Selector */}
          <div className="flex items-center bg-slate-900 p-1 rounded-xl border border-slate-800">
            <button
              id="tab-btn-game"
              onClick={() => setActiveTab('game')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
                activeTab === 'game'
                  ? 'bg-sky-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Gamepad2 className="w-3.5 h-3.5" />
              <span>遊戲試玩區</span>
            </button>
            <button
              id="tab-btn-guide"
              onClick={() => setActiveTab('guide')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
                activeTab === 'guide'
                  ? 'bg-sky-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <ListOrdered className="w-3.5 h-3.5" />
              <span>流程與發布指引</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 max-w-5xl w-full mx-auto px-4 sm:px-6 py-6 sm:py-8">
        {activeTab === 'game' ? (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* Left/Main Column: Playable Game */}
            <div className="lg:col-span-7 flex flex-col items-center">
              {/* Game Selector Sub-bar */}
              <div className="w-full max-w-md flex items-center justify-between mb-3 bg-slate-900 p-1.5 rounded-xl border border-slate-800">
                <span className="text-xs text-slate-400 px-2 font-medium">切換遊戲原型：</span>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => setSelectedGame('dodger')}
                    className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-all ${
                      selectedGame === 'dodger'
                        ? 'bg-sky-500/20 text-sky-300 border border-sky-500/30'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    🚀 星際穿梭避障
                  </button>
                  <button
                    onClick={() => setSelectedGame('snake')}
                    className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-all ${
                      selectedGame === 'snake'
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    🐍 霓虹貪吃蛇
                  </button>
                </div>
              </div>

              {/* Render Active Game */}
              {selectedGame === 'dodger' ? (
                <NeonDodgerGame settings={gameSettings} onUpdateSettings={handleUpdateSettings} />
              ) : (
                <CyberSnakeGame settings={gameSettings} />
              )}
            </div>

            {/* Right Column: Game Customizer & Vibe Assistant Quick Tips */}
            <div className="lg:col-span-5 space-y-4">
              {/* Customizer */}
              <GameCustomizer settings={gameSettings} onChange={handleUpdateSettings} />

              {/* Step E Verification Card */}
              <div className="p-4 bg-slate-900/80 border border-slate-800 rounded-xl space-y-2.5 text-xs">
                <div className="flex items-center gap-2 text-white font-semibold text-sm">
                  <CheckCircle className="w-4 h-4 text-emerald-400" />
                  <span>流程 E 檢驗：遊戲完整度成形標準</span>
                </div>
                <ul className="space-y-1.5 text-slate-300">
                  <li className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                    <span>真的可玩、玩法明確（閃避障礙 / 吃光能量）</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                    <span>包含開始、遊戲結束與重新挑戰循環</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                    <span>即時得分、等級難度提升與最高分紀錄</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                    <span>8-bit Web Audio 合成音效、火花粒子與彩帶特效</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                    <span>完整支援鍵盤 (← → / WASD) 與手機觸控按鈕</span>
                  </li>
                </ul>

                <div className="pt-2 border-t border-slate-800 flex justify-between items-center">
                  <span className="text-[11px] text-slate-400">滿意當前原型後即可進行發布</span>
                  <button
                    onClick={() => setActiveTab('guide')}
                    className="text-xs text-sky-400 hover:text-sky-300 font-semibold underline underline-offset-4"
                  >
                    查看 GitHub & Vercel 部署步驟 →
                  </button>
                </div>
              </div>

              {/* Quick Prompt Composer for Idea */}
              <PromptComposer initialPrompt={composerPrompt} />
            </div>
          </div>
        ) : (
          /* Guide Tab */
          <div className="space-y-6">
            <VibeWorkflowGuide onSelectGamePrompt={handleSelectGamePrompt} />
            <PromptComposer initialPrompt={composerPrompt} />
          </div>
        )}
      </main>

      {/* Footer Standard Announcement */}
      <footer className="w-full border-t border-slate-800/80 bg-slate-950 py-4 px-4 sm:px-6">
        <div className="max-w-5xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>Vibe Coding 操作助理：已就緒</span>
          </div>
          <div className="text-center sm:text-right">
            <span className="font-medium text-slate-300">
              第一階段完成標準：取得 Vercel 公開網址，朋友能實際打開遊戲。
            </span>
          </div>
        </div>
      </footer>
    </div>
  );
}
